import praw
import json
import os

# Load Reddit API credentials from Lambda environment variables
client_id = os.environ['REDDIT_CLIENT_ID']
client_secret = os.environ['REDDIT_CLIENT_SECRET']
user_agent = os.environ['REDDIT_USER_AGENT']

# Initialize the Reddit client
reddit = praw.Reddit(client_id=client_id, client_secret=client_secret, user_agent=user_agent)

def get_posts(subreddit_name, query, limit):
    posts_list = []
    subreddit = reddit.subreddit(subreddit_name)
    for post in subreddit.search(query, sort='new', limit=limit):
        posts_list.append({
            'id': post.id,
            'title': post.title,
            'content': post.selftext,
            'score': post.score,
            'created_utc': post.created_utc,
            'url': post.url,
            'num_comments': post.num_comments
        })
    return posts_list

def lambda_handler(event, context):
    # Extract inputs from the event object
    subreddit_name = event.get('subreddit')
    query = event.get('query')
    limit = event.get('limit', 100)  # Default to 100 if not provided

    # Input validation
    if not subreddit_name or not query:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'subreddit and query are required parameters'})
        }

    # Get posts
    new_posts = get_posts(subreddit_name, query, limit)
    
    # Return as JSON
    return {
        'statusCode': 200,
        'body': json.dumps(new_posts)
    }
